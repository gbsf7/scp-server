―――――――――――――――――――――――――――――――――――――――――
This data pack has been made by KawaMood
―――――――――――――――――――――――――――――――――――――――――

Only websites I currently use to upload my content are Modrinth (modrinth.com), Planet Minecraft (planetminecraft.com) and my own host (kawamood.com).
If this data pack has been downloaded from another website, that means my content has been stolen, so be careful with its content: this data pack can be outdated, or potentially even contains malicious files. Please be sure to download it from one of the websites/platforms stated in the "Links & Contact" section bellow and nowhere else.

―――――――――――――――――――――――――――――――――――――――――
LICENCE
―――――――――――――――――――――――――――――――――――――――――

This data pack follows the CC BY-NC-SA 4.0 licence: https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode

You're free to share and adapt this content under the following terms:
    • Attribution (BY) — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
    • NonCommercial (NC) — You may not use the material for commercial purposes.
    • ShareAlike (SA) — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.

―――――――――――――――――――――――――――――――――――――――――
LINKS & CONTACT
―――――――――――――――――――――――――――――――――――――――――

Mail: contact@kawamood.com
Discord: https://discord.com/invite/w8s9XWgN6v
Website: https://www.kawamood.com
Modrinth: https://modrinth.com/user/KawaMood
Planet Minecraft: https://www.planetminecraft.com/member/kawamood/
Youtube: https://www.youtube.com/@KawaMood
X (Twitter): https://twitter.com/KawaMood